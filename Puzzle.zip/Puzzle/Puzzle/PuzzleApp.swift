//
//  PuzzleApp.swift
//  Puzzle
//
//  Created by Paige Brindle on 3/2/23.
//

import SwiftUI

@main
struct PuzzleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
